 ---- jonathan bressat p1802864 ----
mon projet de LIFAMI est un flipper 
au d�but de la partie une boule est d�pos�e sur la droite.
on la lance en maintenant la fleche vers le bas puis en la relachant (des petits carr�s indique la puissance du lancer)
des bumper sont placer sur le terrain (deux sont placer al�atoirement)
lorsque l'on touche un bumper on gagne des points
lorsque la balle tombe tout en bas on perd une vie (on a 3 vies au d�but)
a 0 vie c'est la d�faite mais on peut r�essayer en appuyant sur 'r'
on contr�le les barres rouges avec les fleches gauche et droite


dans ce projet j'utilise ce que nous avons fais dans le tp 'particule'

je n'utilise pas d'image donc pas de r�pertoire "DATA"