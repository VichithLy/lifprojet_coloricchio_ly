Paul Chambaz P1811567

Ce programme est une simulation Proie Predateur.
Il est realisee sur une grille hexagonale, ce qui change le nombre de voisins, le nombre de case a afficher et le stockage des informations.
Les cases ne sont plus limites a un individu, dans chaque case se trouvent de multiples proies et predateurs. Les individus preferent rester chez eux, mais il leur arrive de partir dans des cases voisines. Les comportements ont donc ete change, il y a une reproduction de base, des comportements de chasse pour les predateurs, et des comportements de limite du sol lorsqu'il y a trop d'individu.
Ce programme contient aussi une comparaison entre la courbe simulee et la courbe obtenue en comptant les individus de l'ecosysteme.