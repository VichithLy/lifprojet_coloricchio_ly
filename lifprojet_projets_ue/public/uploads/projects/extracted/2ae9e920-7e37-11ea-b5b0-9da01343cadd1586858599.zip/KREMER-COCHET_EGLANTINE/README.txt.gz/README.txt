					=> ENSEMBLE DE JULIA <= 



L'ensemble de Julia est une suite complexe définie par Zn+1 = Z0 + C, où C est une constante complexe. 
Lorsqu'on affiche toutes les valeurs de Z0 pour lesquelles la suite est bornée, on obtient un motif, en symétrie centrale autour du complexe nul. En fonction de la valeur de la constante C, le motif est différent. 



Ce programme se présente sous la forme d'une fenêtre, avec un menu qui propose 3 choix. L'affichage de la fenêtre dépend du choix sélectionné dans le menu. 
 
- Le premier choix, intitulé Interpolation 1, présente une cinématique de l'évolution de l'ensemble de Julia entre deux constantes complexes différentes, grâce à une interpolation. 

- Le second choix, intitulé Interpolation 2, fait exactement la même chose mais avec deux autres complexes différents, ce qui affiche une seconde cinématique. 

- Le dernier choix, intitulé Main Libre, utilise la position de la souris pour initialiser la constante C. 





*AFFICHAGE DU MOTIF DE L'ENSEMBLE DE JULIA*


La fenêtre est définie comme tel: chaque pixel correspond à un point d'un repère, d'intervalle [-1.5 ; 1.5] dans l'axe des abscisses et l'axe des ordonnées. 


La fonction Julia renvoie l'indice du premier terme qui est supérieur à la borne (déifinie dans main), si la suite à partir de ce Z0 est bornée. Sinon, si au bout d'un certain nombre d'itérations, la suite n'a toujours pas dépassé la borne, on stoppe le calcule et on considère qu'elle n'est pas bornée. 

La fonction couleur, renvoie une couleur en fonction de cette indice. Si l'indice correspond au nombre d'itérations maximum, on affiche du noir, là où la suite n'est pas bornée. Si dès son premier terme, la suite a dépassé la borne, on affiche du blanc. Et pour toutes les valeurs de l'indice comprises entre 0 et le nombre d'itérations max, c'est une autre couleur qui est affichée. 

En appliquant la fonction Julia et la fonction couleur à tous les pixels de la fenêtre (convertis en points d'un repère), on obtient donc le motif sur la fenêtre, qui est l'affichage de toutes les valeurs de Z0 pour lesquelles la suite sera bornée, avec le complexe C correspondant. 





*INTERPOLATION ET MAIN LIBRE*


Si vous avez bien suivi, vous aurez compris que pour modifier le motif à l'écran, il faut modifier la valeur du complexe C dans la formule. 

Par conséquent, la fonction interpolation va permettre le passage d'un motif à l'autre, en changeant la constante C. Cette fonction va prendre en paramètre la valeur du début, au temps 0, la valeur finale, au temps 1, et le pas de temps, compris entre 0 et 1. Elle va ensuite estimer la valeur qui correspond au temps t. 
À chaque mise à jour, le pas de temps augmente de 0.001, ce qui fait avancer la valeur fournie par la fonction interpolation au fur et à mesure. 


La fonction interpolation va être utilisé pour la partie réelle et la partie imaginaire du complexe C, et va le modifier à chaque passage dans la boucle, ce qui fera évoluer le motif sur la fenêtre. 



Pour la partie main libre, le code n'a plus rien de scientifique, mais j'ai aimé l'idée de rajouter cette option, que je trouve très amusante. 
La fonction C récupère la position de la souris sur la fenêtre, convertie les pixels en point du repère, et renvoie un complexe avec les valeurs correspondant à la position de la souris. Le motif sera donc différent en fonction de la position de celle-ci. 




