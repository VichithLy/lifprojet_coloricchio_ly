
#include <Grapic.h>
#include <math.h>
#include <iostream>
using namespace std;
using namespace grapic;

const int DIMW = 500;

//STRUCTURE COMPLEXE ET TOUS LES SOUS PROGRAMMES QUI LUI SONT ASSOCIÉS

struct Complexe
{
    float x, y;
};

Complexe makeComplexe(float x, float y)
{
    Complexe c;
    c.x=x;
    c.y=y;
    return c;
}

Complexe makeComplexeExp(float r, float theta)
{
    Complexe c;
    c.x=r*cos(theta);
    c.y=r*sin(theta);
    return c;
}

//Fonction de calcul de complexe
Complexe operator + (Complexe c1, Complexe c2)
{
    Complexe c;
    c.x=c1.x+c2.x;
    c.y=c1.y+c2.y;
    return c;
}

Complexe operator *(Complexe c1, Complexe c2)
{
    Complexe c=makeComplexe(c1.x*c2.x - c1.y*c2.y, c1.x*c2.y + c1.y*c2.x);
    return c;
}

Complexe operator *(float l, Complexe c1)
{
    Complexe c;
    c.x=c1.x*l;
    c.y=c1.y*l;
    return c;
}

Complexe operator *(Complexe c1, float l)
{
    Complexe c;
    c.x=l*c1.x;
    c.y=l*c1.y;
    return c;
}

Complexe operator - (Complexe c1, Complexe c2)
{
    Complexe c;
    c.x=c1.x-c2.x;
    c.y=c1.y-c2.y;
    return c;
}

//fonction qui calcule la distance entre deux complexes
float distance (Complexe P1, Complexe P2)
{
    Complexe P=P2-P1;
    return sqrt(P.x*P.x + P.y*P.y);
}


/**********************************************************************************/

//PROGRAMME DE L'ENSEMBLE DE JULIA


//fonction qui renvoie l'indice de du premier de la terme de la suite pour lequel la norme est supérieur à la borne.
//Si la borne n'est pas atteinte au bout d'un nombre iterationMax, alors on arrête le calcul et c'est la valeur d'iterationMax qui est renvoyé.
//borne est la borne, iterationMax est le nombre d'itération à ne pas dépasser, Z0 est le premier terme de la suite, et C est la constante de la suite.
int Julia(float borne, int iterationMax, Complexe Z0, Complexe C)
{
    Complexe Z=Z0;
    int i=0;
    float dZ = distance({0, 0}, Z);
    while(dZ < borne && i < iterationMax){
        dZ = distance({0, 0}, Z);
        Z=Z*Z+C;
        i++;
        }
    return i;
}


//La procédure couleur "renvoie" une couleur en fonction d'un entier i, qui correspond à l'indice i renvoyé par la fonction Julia.
void Couleur(int i, int iterationMax, unsigned char& r, unsigned char& v, unsigned char& b)
{
    int j= (float(i)/float(iterationMax))*255;
    r=j*4;
    v=j*2;
    b=j*3;
}

void drawJulia(int iterationMax, Complexe C)
{
    //pour tous les pixels de la fenêtre
    for(int i=0; i<DIMW; i++){
        for(int j=0; j<DIMW; j++){
            //on calcule les coordonnées sur le repère centré entre [-1.5 ; 1.5] en fonction des coordonnées du pixel
            float x=((float) i)/(DIMW/3)-1.5;
            float y=((float)j)/(DIMW/3)-1.5;
            //Définition du premier terme
            Complexe Z0=makeComplexe(x, y);
            //récupération de l'indice
            int k=Julia(2, iterationMax, Z0, C);
            //attribution de la couleur en fonction de l'indice
            unsigned char r, v, b;
            Couleur(k, iterationMax, r, v, b);
            put_pixel(i, j, r, v, b);
        }
    }
}


//fonction qui renvoie une valeur comprise entre un réel a et un réel b en fonction du temps
float interpolation(float a, float b, float t)
{
    if(t<=1){
        return (a+b)*t;
    }
}

//Fonction qui calcule un nombre complexe C en fonction de la position de la souris sur la fenêtre
Complexe C(){
    int i,j;
    mousePos(i, j);
    float x=((float) i)/(DIMW/3)-1.5;
    float y=((float)j)/(DIMW/3)-1.5;
    Complexe C=makeComplexe(x, y);
    return C;
}



int main(int , char** )
{
    Menu m;
    bool stop=false;
	winInit("Julia", DIMW, DIMW);

	menu_add(m, "Interpolation 1");
	menu_add(m, "Interpolation 2");
	menu_add(m, "Main libre");

	int menuSelect= 0; //cette variable va contenir notre choix dans le menu à la fin de la boucle

    float t=0.32;

	while( !stop )
    {
        winClear();

        int currentMenuSelect=menu_select(m); //contient notre choix au début de la boucle

        switch(currentMenuSelect)
        {
            case 0 :
                //si on change la sélection du menu, la valeur de t est réinitialisée
                if(menuSelect!=currentMenuSelect){
                    t=0.32;
                }
                drawJulia(200, {interpolation(-1, -0.3, t), interpolation(0.8, 1, t)});
                t+=0.001;
                break;

            case 1 :
                //si on change la sélection du menu, la valeur de t est réinitialisée
                if(menuSelect!=currentMenuSelect){
                    t=0.32;
                }
                drawJulia(200, {interpolation(0.1, 1, t), interpolation(0.1, 1, t)});
                t+=0.001;
                break;

            case 2 : drawJulia(200, C() ); break;
        }

        menuSelect=currentMenuSelect;

        menu_draw(m, 0, 0, 500, 50);

        stop = winDisplay();
    }
    winQuit();
	return 0;
}

