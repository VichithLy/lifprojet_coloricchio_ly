Le principe est un Billard en plus simplifi�, il faut juste rentrer toutes les balles avant de rentrer la balle blanche.

Si la balle blanche est rentrer avant les autres elle peut �tre replac�e n'importe o� sur la table, � l'exeption de l'emplacement des autres balles.

Il y a une petite aide en maintenant la touche 'A'. Avec l'affichage des r�gles de jeu, la possibilit� d'arr�ter toutes les balles et celle de recommencer la partie.

Pour le tir il y a une pr�visualisation, lors du tir il n'y a plus la possibilit� de tirer tant que la balle blanche n'est pas immobile.

Les collisions avec les bords sont pr�sentes et aussi celles des trous dans lesquelles doivent rentrer toutes les balles.

Lors d'un choc entre deux balles, le calcul des vitesses est r�alis� et il est r�alis� avec une matrice transpos�e pour recalculer les nouvelles vitesses.

Si une balle est rentr�e, alors son �tat change. L'�tat des ballles sont affich�s en haut � gauche. Vide pour la balle sur la table et pleine pour la balle qui est dans le trou.

Une fois toutes les balles rentr�es, l'�cran des statiqtiques appara�t et vous montre diff�rentes statiqtiques sur vos balles (temps de survie, vitesse moyenne, nombre de rebond sur la bande, nombre de collision avec une autre balle, nombre de fois o� les balles sont rentr�es, nombre d'�rret manuel des balles).

Si vous passez votre souris sur les balles qui sont en haut vous avez la possibilit� de voir les statistiques individuelles de chacunes d'entre elles.

Et puis pour terminer vous n'avez plus qu'� faire 'esc' pour fermer le programme.